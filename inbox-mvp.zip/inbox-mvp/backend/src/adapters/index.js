const whatsapp = require('./whatsapp');
const instagram = require('./instagram');
const messenger = require('./messenger');
const telegram = require('./telegram');

module.exports = {
  whatsapp,
  instagram,
  messenger,
  telegram
};

