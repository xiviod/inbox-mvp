import Inbox from './components/Inbox';

const App = () => <Inbox />;

export default App;

